var searchData=
[
  ['ges_20ko_3anyvta_20r_0',['@brief          : Folyade&apos;k krista&apos;lyos LCD I2C-vel csatlakoza&apos;sa&apos;hoz szu:kse&apos;ges ko:nyvta&apos;r',['../liquidcrystal__i2c_8h.html#autotoc_md0',1,'']]],
  ['gpio_2ec_1',['gpio.c',['../gpio_8c.html',1,'']]],
  ['gpio_2eh_2',['gpio.h',['../gpio_8h.html',1,'']]]
];
