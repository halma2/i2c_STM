var indexSectionsWithContent =
{
  0: ":abcdefghiklmnprstuv",
  1: "gilms",
  2: "bdehmnpsu",
  3: "adhs",
  4: "adehilmprtuv",
  5: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "groups"
};

var indexSectionLabels =
{
  0: "Összes",
  1: "Fájlok",
  2: "Függvények",
  3: "Változók",
  4: "Makródefiníciók",
  5: "Modulok"
};

