var searchData=
[
  ['r_0',['@brief          : Folyade&apos;k krista&apos;lyos LCD I2C-vel csatlakoza&apos;sa&apos;hoz szu:kse&apos;ges ko:nyvta&apos;r',['../liquidcrystal__i2c_8h.html#autotoc_md0',1,'']]],
  ['register_1',['Commands in LDC instruction Register',['../liquidcrystal__i2c_8h.html#autotoc_md1',1,'']]],
  ['rs_2',['RS',['../liquidcrystal__i2c_8h.html#af8903d8eea3868940c60af887473b152',1,'liquidcrystal_i2c.h']]],
  ['rw_3',['RW',['../liquidcrystal__i2c_8h.html#afc4ded33ac0ca43defcce639e965748a',1,'liquidcrystal_i2c.h']]]
];
